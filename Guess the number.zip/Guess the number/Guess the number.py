#visit Dhermil.github.io
#Game : guess the number between 1 and 1000

from random import *
from math import sqrt

attempt=['first', 'second', 'third',
       'fourth', 'fifth', 'sixth',
       'seventh', 'eighth', 'nineth',
       'tenth']

to_guess = str(randint(1,1000))
list_to_guess = list(to_guess)

length = len(to_guess)
greatest = max(list_to_guess)
smallest = min(list_to_guess)
square_root = sqrt(int(to_guess))
first = list_to_guess[0]
last = list_to_guess[len(list_to_guess)-1]

clues = {'How much digit in the number you are guessing :' : [length],
          'The greatest digit of this number is : '  : [greatest],
          'The square root of this number is (do not use your calculator !) : ' : [square_root],
          'The last digit of this number is : ' : [last],
          'The smallest digit of this number is : ' : [smallest],
          'The first digit of this number is : ' : [first] }

print('First attempt :')

answer = input('Type a number : ')

if answer != to_guess :
        global n_attempt
        n_attempt = 1
        for k, v in clues.items():
            print(k, v[0])
            answer = input('Let\'s go ! Another attempt : ')
            n_attempt +=1
            if answer != to_guess :
                continue
            else :
                print('Congratulations ! Found after', attempt[n_attempt - 1], 'attempts !')
                break

else :
    print('Incredible ! Only', attempt[0] ,'attempt !')

if answer != to_guess :
    print('Too bad, the number was', to_guess ,'.')
    

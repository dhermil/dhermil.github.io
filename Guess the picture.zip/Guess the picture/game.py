from tkinter import *

score = 0  #score initialisation

#the game
def game():
    #editing of the menu window
    window = Tk()
    window.title("Guess the picture")
    window.geometry('600x300')

#function to add 1 to the score
    def up():
        global score
        score += 1

#function to add 2 to the score
    def up2():
        global score
        score +=2

###########################
##### REAL CHARACTERS #####
###########################
        
    def real_characters():
        window.destroy() #shut the menu window
        
        for i in range(6):

            if i == 1: #first picture to guess
                game_window = Tk()
                game_window.title("Guess the picture : Real characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar() #save the answer under 'user_answer'
                saisie = Entry(game_window, textvariable = user_answer) #entry widget for the user
                saisie.pack() 
                photo = PhotoImage(file = "1beckhamF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event): # function that check the validity of the user answer,
                    # if it is valid the function (up) is called

                    if (str(user_answer.get()).lower()) in ["david beckham","beckham", "davidbeckham"] :
                        up2()    
                        game_window.destroy()

                    else: #if there is no answer or a false one
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1=PhotoImage(file = "1beckham.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if (str(user_answer1.get()).lower()) in ["david beckham","davidbeckham", "beckham"] :
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 ) #button to check the validity of the answer
                        game_window1.bind("<Return>", check1) #to validate with the 'enter' key
                        button_validate1.pack()
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check) #button to check the validity of the answer
                game_window.bind("<Return>", check)
                button_validate.pack()
                game_window.mainloop()

                
            if i == 2:
                game_window = Tk()
                game_window.title("Guess the picture : Real characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack() 
                photo = PhotoImage(file = "1putinF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):

                    if (str(user_answer.get()).lower()) in ["putin","vladimir putin","vladimir vladimirovitch putin" ,"vladimirputin"] :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "1putin.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if (str(user_answer1.get()).lower()) in ["putin","vladimir putin","vladimir vladimirovitch putin" ,"vladimirputin"] :
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text ='Confirm', command = check1 )
                        game_window1.bind("<Return>", check1)
                        button_validate1.pack()
                        game_window1.mainloop()

                button_validate = Button(game_window, text ='Confirm', command = check)
                game_window.bind("<Return>", check)
                button_validate.pack()
                game_window.mainloop()
            
            if i == 3:
                game_window = Tk()
                game_window.title("Guess the picture : Real characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer )
                saisie.pack() 
                photo = PhotoImage(file = "1peleF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):

                    if str(user_answer.get()).lower() in ["pele","péle", "pélé"]:
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack()
                        photo1 = PhotoImage(file = "1pele.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() in ["pele","pélé", "péle"]:
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text ='Confirm', command= check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text ='Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
            
            if i == 4:
                game_window = Tk()
                game_window.title("Guess the picture : Real characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack() 
                photo = PhotoImage(file = "1mandelaF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() in ["mandela","nelson mandela"] :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "1mandela.gif")
                        picture1 = Label(game_window1, image=photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() in ["mandela","nelson mandela"] :
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 5:
                game_window = Tk()
                game_window.title("Guess the picture : Real characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack() 
                photo = PhotoImage(file = "1usain_boltF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() in ["bolt","usain bolt"] :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1=PhotoImage(file = "1usain_bolt.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() in ["bolt","usain bolt"] :
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()

        
###########################
##  FICTIONAL CHARACTERS ##
###########################
        
    def fictional_characters():
        window.destroy()
        
        for i in range(6):
            
            if i == 1:
                game_window = Tk()
                game_window.title("Guess the picture :  Fictional characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file="2captain_tsubasaF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()
                
                def check(event):
                    if str(user_answer.get()).lower() in  ["captain tsubasa", "olive", "olive and tom"] :
                        up2()
                        game_window.destroy()
                        
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1=PhotoImage(file = "2captain_tsubasa.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()
                        
                        def check1(event):
                            if str(user_answer1.get()).lower() in  ["captain tsubasa", "olive", "olive and tom"] :
                                up()
                            game_window1.destroy()
                            
                        button_validate1 = Button(game_window1, text ='Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 2:
                game_window = Tk()
                game_window.title("Guess the picture :  Fictional characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file="2homerF.gif")
                picture = Label(game_window, image=photo)
                picture.pack()
                
                def check(event):
                    if str(user_answer.get()).lower() in ["homer simpson", "homer", "simpson"] :
                        up2()
                        game_window.destroy()
                        
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "2homer.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()
                        
                        def check1(event):
                            if str(user_answer1.get()).lower() in ["homer simpson", "homer", "simpson"] :
                                up()
                            game_window1.destroy()
                            
                        button_validate1 = Button(game_window1, text ='Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 3:
                game_window = Tk()
                game_window.title("Guess the picture :  Fictional characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable=user_answer)
                saisie.pack()
                photo = PhotoImage(file = "2trevorF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()
                
                def check(event):
                    if str(user_answer.get()).lower() == "trevor" :
                        up2()
                        game_window.destroy()
                        
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1=PhotoImage(file = "2trevor.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()
                        
                        def check1(event):
                            if str(user_answer1.get()).lower == "trevor":
                                up()
                            game_window1.destroy()
                            
                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 4:
                game_window = Tk()
                game_window.title("Guess the picture :  Fictional characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file="2shadowF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()
                
                def check(event):
                    if str(user_answer.get()).lower() == "shadow" :
                        up2()
                        game_window.destroy()
                        
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "2shadow.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()
                        
                        def check1(event):
                            if str(user_answer1.get()).lower() == "shadow":
                                up()
                            game_window1.destroy()
                            
                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 5:
                game_window = Tk()
                game_window.title("Guess the picture :  Fictional characters")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "2pichuF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()
                
                def check(event):
                    if str(user_answer.get()).lower() == "pichu" :
                        up2()
                        game_window.destroy()
                        
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Real characters")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "2pichu.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()
                        
                        def check1(event):
                            if str(user_answer1.get()).lower() == "pichu":
                                up()
                            game_window1.destroy()
                            
                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                      

#############################
# MOVIES TV SHOWS AND GAMES #
#############################
        
    def moviestvshowsgames():
        window.destroy()
        
        for i in range(6):
            
            if i == 1:
                game_window = Tk()
                game_window.title("Guess the picture : Movies, tv shows and games")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file="3breaking_badF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()
                
                def check(event):
                    if str(user_answer.get()).lower() in ["breaking bad", "walter white", "breakingbad"] :
                        up2()
                        game_window.destroy()
                        
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Movies, tv shows and games")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "3breaking_bad.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()
                        
                        def check1(event):
                            if str(user_answer1.get()).lower() in ["breaking bad", "walter white", "breakingbad"] :
                                up()
                            game_window1.destroy()
                            
                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
            
            if i == 2:
                game_window = Tk()
                game_window.title("Guess the picture :Movies, tv shows and games")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "3counter_strikeF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()
                
                def check(event):
                    if str(user_answer.get()).lower in ["counter strike", "counterstrike", "cs"] :
                        up2()
                        game_window.destroy()
                        
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Movies, tv shows and games")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file="3counter_strike.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()
                        
                        def check1(event):
                            if str(user_answer1.get()).lower in ["counter strike", "counterstrike", "cs"] :
                                up()
                            game_window1.destroy()
                            
                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()
                        
                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 3:
                game_window = Tk()
                game_window.title("Guess the picture : Movies, tv shows and games")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "3half_lifeF.gif")
                picture = Label(game_window, image=photo)
                picture.pack()
                def check(event):
                    if str(user_answer.get()).lower() == "half life" :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Movies, tv shows and games")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "3half_life.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() == "half life":
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 4:
                game_window = Tk()
                game_window.title("Guess the picture : Movies, tv shows and games")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack() 
                photo = PhotoImage(file = "3the_godfatherF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() in ["the godfather"] :
                        up2()
                        game_window.destroy()
                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Movies, tv shows and games")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "3the_godfather.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() in ["the godfather"] :
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 5:
                game_window = Tk()
                game_window.title("Guess the picture : Movies, tv shows and games")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack() 
                photo = PhotoImage(file = "3the_witcherF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "the witcher" :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Movies, tv shows and games")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "3the_witcher.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() == "the witcher":
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()


###########################
#### CITIES AND FLAGS  ####
###########################
        
    def cities_flags():
        window.destroy()

        for i in range(6):

            if i == 1:
                game_window = Tk()
                game_window.title("Guess the picture : Cities and flags")
                game_window.geometry('1920x1080')   
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "4indiaF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "india" :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Cities and flags")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "4india.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() == "india":
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()

            if i == 2:
                game_window = Tk()
                game_window.title("Guess the picture : Cities and flags")
                game_window.geometry('1920x1080')   
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "4los_angelesF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() in ["los angeles", "la"]:
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Cities and flags")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "4los_angeles.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() in ["los angeles", "la"]:
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()

            if i == 3:
                game_window = Tk()
                game_window.title("Guess the picture : Cities and flags")
                game_window.geometry('1920x1080')   
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "4moscowF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "moscow" :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Cities and flags")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "4moscow.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() == "moscow":
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()   

            if i == 4:
                game_window = Tk()
                game_window.title("Guess the picture : Cities and flags")
                game_window.geometry('1920x1080')   
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "4sydneyF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "sydney" :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Cities and flags")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "4sydney.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer.get()).lower() == "sydney":
                                up()
                            game_window1.destroy()

                        button_validate1 = Button(game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()

            if i == 5:
                game_window = Tk()
                game_window.title("Guess the picture : Cities and flags")
                game_window.geometry('1920x1080')   
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file="4yougoslaviaF.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "yougoslavia" :
                        up2()
                        game_window.destroy()

                    else:
                        game_window.destroy()
                        game_window1 = Tk()
                        game_window1.title("Guess the picture : Cities and flags")
                        game_window1.geometry('1920x1080')   
                        user_answer1 = StringVar()
                        saisie1 = Entry(game_window1, textvariable = user_answer1)
                        saisie1.pack() 
                        photo1 = PhotoImage(file = "4yougoslavia.gif")
                        picture1 = Label(game_window1, image = photo1)
                        picture1.pack()

                        def check1(event):
                            if str(user_answer1.get()).lower() == "yougoslavia":
                                up()
                            game_window1.destroy()

                        button_validate1 = Button( game_window1, text = 'Confirm', command = check1 )
                        button_validate1.pack()
                        game_window1.bind("<Return>", check1)
                        game_window1.mainloop()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()            


#############
### LOGOS ###
#############
        
    def logos():
        window.destroy()

        for i in range(6):

            if i == 1:
                game_window = Tk()
                game_window.title("Guess the picture : Logos")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "5xiaomi.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "xiaomi" :
                        up()
                    game_window.destroy()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 2:
                game_window = Tk()
                game_window.title("Guess the picture : Logos")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "5spotify.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "spotify" :
                        up()
                    game_window.destroy()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()

            if i == 3:
                game_window = Tk()
                game_window.title("Guess the picture : Logos")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "5playstation.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "playstation" :
                        up()
                    game_window.destroy()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()

            if i == 4:
                game_window = Tk()
                game_window.title("Guess the picture : Logos")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "5mastercard.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "mastercard" :
                        up()
                    game_window.destroy()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                
            if i == 5:
                game_window = Tk()
                game_window.title("Guess the picture : Logos")
                game_window.geometry('1920x1080')
                user_answer = StringVar()
                saisie = Entry(game_window, textvariable = user_answer)
                saisie.pack()
                photo = PhotoImage(file = "5dropbox.gif")
                picture = Label(game_window, image = photo)
                picture.pack()

                def check(event):
                    if str(user_answer.get()).lower() == "dropbox" :
                        up()
                    game_window.destroy()

                button_validate = Button(game_window, text = 'Confirm', command = check)
                button_validate.pack()
                game_window.bind("<Return>", check)
                game_window.mainloop()
                  

########################
###                  ###
###  END OF PICTURES ###
###                  ###
########################

#Text shown in the menu
    Label(text = "\n Welcome ! \n You are going to play 'Guess the picture' by Dhermil (dhermil.github.io) \n You have the choice for 5 game modes \n For each one, you will have 5 pictures to guess \n Guessing a pixelated or partially hidden picture gives you 2 points \n while guessing a normal picture gives you only one point. \n").pack()

#5 buttons for 5 different game modes
    button1 = Button(text = "Launch the 'Real characters' game mode", command = real_characters)
    button2 = Button(text = "Launch the 'Fictional characters' game mode", command = fictional_characters)
    button3 = Button(text = "Launch the 'Movies, tv shows and games' game mode", command = moviestvshowsgames)
    button4 = Button(text = "Launch the 'Cities and flags' game mode", command = cities_flags)
    button5 = Button(text = "Launch the 'Logos' game mode", command = logos)
    button1.pack()
    button2.pack()
    button3.pack()
    button4.pack()
    button5.pack()
    window.mainloop()


#end window
def menu_end():
    end_window = Tk()
    end_window.title("Save your party ?")
    end_window.geometry('600x150')
    Label(text= "Your score : " + str(score) + "\n" + "Save it ?").pack() #printing of the score and ask the user if he wants to save or not

    #window of score saving 
    def add_score():
        end_window.destroy() #shutting the end window
        save_window =Tk() 
        save_window.title("Saving your game")
        save_window.geometry('600x150')
        Label(save_window, text = "Your name : ").pack() #asking the user his name
        input_name = StringVar() #saving the user name under 'input_name'
        name = Entry(save_window, textvariable = input_name)
        name.pack()

        def save_score(event):
            add(str(input_name.get()),str(score)) #Executing the 'add' function
            save_window.destroy()

        def save_score_button():
            add(str(input_name.get()),str(score)) #Executing the 'add' function
            save_window.destroy()

        button_validation = Button(save_window, text = "validate", command=save_score_button)
        button_validation.pack()
        save_window.bind("<Return>", save_score)
        save_window.mainloop()

    def one_more():
        menu()
 
    #Choices for the user 
    button_yes = Button(end_window, text='Save', command = add_score )
    button_no = Button(end_window, text='Do not Save', command = end_window.destroy )
    button_yes.pack()
    button_no.pack()
    end_window.mainloop()

#Function to add name + score of the user to an external file
def add(name, score):
    file_write = open('scores.txt' , 'a')
    file_write.write(name + " : " + score + "\n")
    file_write.close()

#function sorting a score table
def sort(t):
    t.sort(key = lambda x : int(x.split(" : ")[1]), reverse = True)
    
#function sorting the results
def to_sort():
    t=[]
    file_read = open("scores.txt", 'r')
    for ligne in file_read :
        t.append(ligne)
    file_read.close()
    sort(t)
    print('Players standings :')
    print()
    for ligne in t :
        print(ligne, end="")
    print()
    
#Launch the game
def menu():
    game()
    menu_end()

menu()

############
### TEST ###
############

# To check the standings, type the following : to_sort()


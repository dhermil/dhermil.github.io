from tkinter import *


#initialisation du score à 0
score = 0


#Le jeu
def Jeu():
    
#Création de la fenêtre du jeu (grâce à Tkinter, puis définition de son titre et taille)
    fen = Tk()
    fen.title("Devine l'image")
    fen.geometry('600x300')

#Fonction permettant d'ajouter un point au score
    def up():
        global score
        score += 1


#Mode Personnage réels
    def PersosReels():
        fen.destroy() #Fermeture de la fenêtre d'accueil
        
#Première fenêtre pour première image à deviner (c'est le même schéma pour chaucune des 5 images des 5 modes de jeu)
        def image1():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages réels")
            fenJeu.geometry('1920x1080')
            reponse = StringVar() #Permet d'enregistrer la saisie du joueur sous 'reponse'
            saisie = Entry(fenJeu, textvariable=reponse) #Widget Entry pour que le joueur saisisse sa réponse
            saisie.pack()
            photo=PhotoImage(file="1arouf_gangsta.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification(): # Fonction permettant de vérifier si la saisie du joueur coincide avec la réponse, si elle est validée on utilise la fontion (up)
                if str(reponse.get()) == "arouf gangsta" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification ) #Bouton permettant au joueur de valider sa réponse et l'enregistrer
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy ) #Bouton permettant au joueur de passer à la prochaine image en fermant la première.
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image2():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages réels")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="1defunes.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "de funès" or str(reponse.get()) == "louis de funès" or str(reponse.get()) == "louis de funes" or str(reponse.get()) == "de funes":
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image3():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages réels")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="1hollande.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "hollande" or str(reponse.get()) == "françois hollande" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image4():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages réels")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="1mandela.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "mandela" or str(reponse.get()) == "nelson mandela" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image5():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages réels")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="1usain_bolt.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "bolt" or str(reponse.get()) == "usain bolt" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        image1()
        image2()
        image3()
        image4()
        image5()
        
    def PersosFictifs():
        fen.destroy()
        def image1():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages fictifs")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="2captain_tsubasa.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "captain tsubasa" or str(reponse.get()) == "olive" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image2():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages fictifs")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="2homer.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "homer simpson" or str(reponse.get()) == "homer" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image3():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages fictifs")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="2trevor.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "trevor" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image4():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages fictifs")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="2shadow.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "shadow" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image5():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Personnages fictifs")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="2pichu.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "pichu" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        image1()
        image2()
        image3()
        image4()
        image5()
        
        
    def filmsSeriesJeux():
        fen.destroy()

        
        def image1():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Films, séries et jeux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="3breaking_bad.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "breaking bad" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image2():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Films, séries et jeux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="3counter_strike.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "counter strike" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image3():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Films, séries et jeux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="3half_life.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "half life" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image4():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Films, séries et jeux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="3le_parrain.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "le parrain" or str(reponse.get()) == "the godfather" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image5():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Films, séries et jeux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="3the_witcher.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "the witcher" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        image1()
        image2()
        image3()
        image4()
        image5()

        
    def VillesDrapeaux():
        fen.destroy()
        def image1():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Villes et drapeaux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="4inde.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "inde" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image2():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Villes et drapeaux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="4los_angeles.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "los angeles" or str(reponse.get()) == "la" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image3():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Villes et drapeaux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="4moscou.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "moscou" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image4():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Villes et drapeaux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="4sydney.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "sydney" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image5():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Villes et drapeaux")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="4yougoslavie.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "yougoslavie" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        image1()
        image2()
        image3()
        image4()
        image5()

        
    def Logos():
        fen.destroy()
        def image1():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Logos")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="5dropbox.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "dropbox" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image2():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Logos")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="5mastercard.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "mastercard" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image3():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Logos")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="5playstation.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "playstation" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image4():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Logos")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="5spotify.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "spotify" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        def image5():
            fenJeu = Tk()
            fenJeu.title("Devine l'image : Logos")
            fenJeu.geometry('1920x1080')
            reponse = StringVar()
            saisie = Entry(fenJeu, textvariable=reponse)
            saisie.pack()
            photo=PhotoImage(file="5xiaomi.gif")
            labl = Label(fenJeu, image=photo)
            labl.pack()

            def verification():
                if str(reponse.get()) == "xiaomi" :
                    up()
            
            boutonValider = Button(fenJeu, text ='Valider', command=verification )
            boutonValider.pack()            
            boutonValider = Button(fenJeu, text ='Prochaine image', command=fenJeu.destroy )
            boutonValider.pack()
            fenJeu.mainloop()

            
        image1()
        image2()
        image3()
        image4()
        image5()
        

#Texte affiché sur le menu
    Label(text = "\n Bienvenu, \n Vous êtes sur le jeu Devine l'image fait par : Mohamed, Joshan et Adam \n Vous avez 5 choix de modes de jeu \n Pour chacun des modes, vous aurez 5 images à deviner. \n Attention : Vous devrez saisir votre réponse en minuscule\n").pack()

#5 boutons pour les 5 modes de jeux différents
    bouton1 = Button(text = 'Lancer le mode Personnages réels', command=PersosReels)
    bouton2 = Button(text = 'Lancer le mode Personnages fictifs', command=PersosFictifs)
    bouton3 = Button(text = 'Lancer le mode Films, séries et jeux', command=filmsSeriesJeux)
    bouton4 = Button(text = 'Lancer le mode Villes et drapeaux', command=VillesDrapeaux)
    bouton5 = Button(text = 'Lancer le mode Logos', command=Logos)
    bouton1.pack()
    bouton2.pack()
    bouton3.pack()
    bouton4.pack()
    bouton5.pack()
    fen.mainloop()


#Fenetre de menu de fin de jeu
def menuFin():
    fenFin= Tk() #Création de la fenêtre
    fenFin.title("Sauvegarde de votre partie")
    fenFin.geometry('600x150')
    Label(text= "Votre score :" + str(score) + "\n" + "Sauvegarder ?").pack() #Affichage du score et demande au joueur s'il veut, ou non, sauvegarder

#Fenetre d'ajout de score
    def ajoutScore():
        fenFin.destroy() #Fermeture de la fenêtre du menu de fin de jeu
        fenSauvegarde =Tk() #Création de la fenêtre
        fenSauvegarde.title("Sauvegarde de votre partie")
        fenSauvegarde.geometry('600x150')
        Label(fenSauvegarde, text = "Votre nom ?").pack() #Demande au joueur son nom
        nomSaisi = StringVar() #Sauvegarde de son nom dans 'nomSaisi'
        nom = Entry(fenSauvegarde, textvariable = nomSaisi)
        nom.pack()

#Fenêtre du menu rejouer
        def menuRejouer():
            ajouter(str(nomSaisi.get()),str(score)) #Execution de la fonction 'ajouter'
            fenSauvegarde.destroy() #Fermeture de la fenêtre de sauvegarde
            fenRejouer = Tk() #Création de la fenêtre pour demander au joueur s'il veut rejouer ou non
            fenRejouer.title("Rejouer")
            fenRejouer.geometry('600x150')
            Label(fenRejouer, text = "Rejouer ?").pack()

#Fonction permettant de fermer la fenêtre 'rejouer' et relance le jeu
            def rejouer():
                fenRejouer.destroy()
                menu()
                
#Boutons pour permettre au joueur de faire un choix                
            boutonOui2 = Button(fenRejouer, text='Oui', command = rejouer )
            boutonNon2 = Button(fenRejouer, text='Non', command = fenRejouer.destroy)
            boutonOui2.pack()
            boutonNon2.pack()

#Bouton permettant de valider et de lancer la fenêtre rejouer            
        boutonValidation = Button(fenSauvegarde, text ="Valider", command = menuRejouer)
        boutonValidation.pack()

#Choix pour le joueur ( Oui pour sauvegarder sinon fermeture de la fenêtre)
    boutonOui = Button(fenFin, text='Oui', command = ajoutScore )
    boutonNon = Button(fenFin, text='Non', command = fenFin.destroy)
    boutonOui.pack()
    boutonNon.pack()

#Fonction permettant le lancement du jeu
def menu():
    Jeu()
    menuFin()

#Fonction permettant d'ajouter le nom et le score du joueur à un fichier
def ajouter(nom, score):
    fichier_ecriture = open('scores.txt' , 'a')
    fichier_ecriture.write(nom + " " + score + "\n")
    fichier_ecriture.close()

menu()

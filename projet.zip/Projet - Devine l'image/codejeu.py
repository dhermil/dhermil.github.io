from tkinter import *

score = 0

#Le jeu
def Jeu():
#Création de la fenêtre du jeu (grâce à Tkinter, puis définition de son titre et taille)
    fen = Tk()
    fen.title("Devine l'image")
    fen.geometry('600x300')

#Fonction permettant d'ajouter un point au score
    def up():
        global score
        score += 1
#Fonction permettant d'ajouter 2 points au score
    def up2():
        global score
        score +=2

###########################
### PERSONNAGES REELS #####
###########################
        
#Mode Personnage réels
    def PersosReels():
        fen.destroy() #Fermeture de la fenêtre d'accueil
        for i in range(6):
            if i==1:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages réels")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()#Permet d'enregistrer la saisie du joueur sous 'reponse'
                saisie = Entry(fenJeu, textvariable=reponse)#Widget Entry pour que le joueur saisisse sa réponse
                saisie.pack() 
                photo=PhotoImage(file="1arouf_gangstaF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification(): # Fonction permettant de vérifier si la saisie du joueur coincide avec la réponse, si elle est validée on utilise la fontion (up)
                    if str(reponse.get()) == "arouf gangsta" :
                        up2()    
                        fenJeu.destroy()
                    else: #Si la réponse n'est pas présente ou incorrecte
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="1arouf_gangsta.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse1.get()) == "arouf gangsta" :
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 ) #Bouton permettant au joueur de valider sa réponse et l'enregistrer
                        boutonValider1.pack()
                        fenJeu1.mainloop()    
                boutonValider = Button(fenJeu, text ='Valider', command=verification ) #Bouton permettant au joueur de valider sa réponse et l'enregistrer
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==2:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages réels")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack() 
                photo=PhotoImage(file="1defunesF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "de funès" or str(reponse.get()) == "louis de funès" or str(reponse.get()) == "louis de funes" or str(reponse.get()) == "de funes":
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="1defunes.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "de funès" or str(reponse.get()) == "louis de funès" or str(reponse.get()) == "louis de funes" or str(reponse.get()) == "de funes":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()             
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
            
            if i==3:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages réels")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack() 
                photo=PhotoImage(file="1hollandeF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "hollande" or str(reponse.get()) == "françois hollande":
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="1hollande.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "hollande" or str(reponse.get()) == "françois hollande":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()        
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
            
            if i==4:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages réels")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack() 
                photo=PhotoImage(file="1mandelaF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "mandela" or str(reponse.get()) == "nelson mandela" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="1mandela.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "mandela" or str(reponse.get()) == "nelson mandela":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==5:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages réels")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack() 
                photo=PhotoImage(file="1usain_boltF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "bolt" or str(reponse.get()) == "usain bolt" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="1usain_bolt.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "bolt" or str(reponse.get()) == "usain bolt":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()

        
###########################
### PERSONNAGES FICTIFS ###
###########################
        
    def PersosFictifs():
        fen.destroy()
        for i in range(6):
            if i==1:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages fictifs")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="2captain_tsubasaF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "captain tsubasa" or str(reponse.get()) == "olive" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="2captain_tsubasa.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "captain tsubasa" or str(reponse.get()) == "olive":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==2:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages fictifs")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="2homerF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "homer simpson" or str(reponse.get()) == "homer" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="2homer.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "homer" or str(reponse.get()) == "homer simpson":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==3:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages fictifs")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="2trevorF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "trevor" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="2trevor.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "trevor":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==4:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages fictifs")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="2shadowF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "shadow" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="2shadow.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "shadow":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==5:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Personnages fictifs")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="2pichuF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "pichu" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="2pichu.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "pichu":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                      

############################
### FILMS SERIES ET JEUX ###
############################
        
    def filmsSeriesJeux():
        fen.destroy()
        for i in range(6):
            if i==1:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Films, séries et jeux")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="3breaking_badF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "breaking bad" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="3breaking_bad.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "breaking bad":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
            
            if i==2:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Films, séries et jeux")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="3counter_strikeF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "counter strike" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="3counter_strike.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "counter strike":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==3:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Films, séries et jeux")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="3half_lifeF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "half life" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="3half_life.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "half life":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==4:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Films, séries et jeux")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack() 
                photo=PhotoImage(file="3le_parrainF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "le parrain" or str(reponse.get()) == "the godfather" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="3le_parrain.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "le parrain" or str(reponse.get()) == "the godfather":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==5:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Films, séries et jeux")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack() 
                photo=PhotoImage(file="3the_witcherF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "the witcher" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="3the_witcher.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "the witcher":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()


###########################
### VILLES ET DRAPEAUX ####
###########################
        
    def VillesDrapeaux():
        fen.destroy()
        for i in range(6):
            if i==1:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Villes et drapeaux")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="4indeF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "inde" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="4inde.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "inde":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()

            if i==2:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Villes et drapeaux")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="4los_angelesF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "los angeles":
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="4los_angeles.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "los angeles":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()

            if i==3:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Villes et drapeaux")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="4moscouF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "moscou" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="4moscou.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "moscou":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()   

            if i==4:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Villes et drapeaux")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="4sydneyF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "sydney" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="4sydney.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "sydney":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()

            if i==5:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Villes et drapeaux")
                fenJeu.geometry('1920x1080')   
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="4yougoslavieF.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "yougoslavie" :
                        up2()
                        fenJeu.destroy()
                    else:
                        fenJeu.destroy()
                        fenJeu1 = Tk()
                        fenJeu1.title("Devine l'image : Personnages réels")
                        fenJeu1.geometry('1920x1080')   
                        reponse1 = StringVar()
                        saisie1 = Entry(fenJeu1, textvariable=reponse1)
                        saisie1.pack() 
                        photo1=PhotoImage(file="4yougoslavie.gif")
                        labl1 = Label(fenJeu1, image=photo1)
                        labl1.pack()
                        def verification1():
                            if str(reponse.get()) == "yougoslavie":
                                up()
                            fenJeu1.destroy()
                        boutonValider1 = Button(fenJeu1, text ='Valider', command=verification1 )
                        boutonValider1.pack()
                        fenJeu1.mainloop()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()            


#############
### LOGOS ###
#############
        
    def Logos():
        fen.destroy()
        for i in range(6):
            if i==1:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Logos")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="5xiaomi.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "xiaomi" :
                        up()
                    fenJeu.destroy()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==2:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Logos")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="5spotify.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "spotify" :
                        up()
                    fenJeu.destroy()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()

            if i==3:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Logos")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="5playstation.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "playstation" :
                        up()
                    fenJeu.destroy()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()

            if i==4:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Logos")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="5mastercard.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "mastercard" :
                        up()
                    fenJeu.destroy()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                
            if i==5:
                fenJeu = Tk()
                fenJeu.title("Devine l'image : Logos")
                fenJeu.geometry('1920x1080')
                reponse = StringVar()
                saisie = Entry(fenJeu, textvariable=reponse)
                saisie.pack()
                photo=PhotoImage(file="5dropbox.gif")
                labl = Label(fenJeu, image=photo)
                labl.pack()
                def verification():
                    if str(reponse.get()) == "dropbox" :
                        up()
                    fenJeu.destroy()
                boutonValider = Button(fenJeu, text ='Valider', command=verification )
                boutonValider.pack()
                fenJeu.mainloop()
                  

            ########################
            ###                ^ ###
            ### FIN DES IMAGES ^ ###
            ###                ^ ###
            ########################

#Texte affiché sur le menu
    Label(text = "\n Bienvenue, \n Vous êtes sur le jeu Devine l'image fait par : Mohamed, Joshan et Adam \n Vous avez 5 choix de modes de jeu \n Pour chacun des modes, vous aurez 5 images à deviner. \n Une image pixélisée ou partiellement cachée vous donne 2 points alors qu'une image normale 1 seul point \n Attention : Vous devrez saisir votre réponse en minuscule\n ").pack()

#5 boutons pour les 5 modes de jeux différents
    bouton1 = Button(text = 'Lancer le mode Personnages réels', command=PersosReels)
    bouton2 = Button(text = 'Lancer le mode Personnages fictifs', command=PersosFictifs)
    bouton3 = Button(text = 'Lancer le mode Films, séries et jeux', command=filmsSeriesJeux)
    bouton4 = Button(text = 'Lancer le mode Villes et drapeaux', command=VillesDrapeaux)
    bouton5 = Button(text = 'Lancer le mode Logos', command=Logos)
    bouton1.pack()
    bouton2.pack()
    bouton3.pack()
    bouton4.pack()
    bouton5.pack()
    fen.mainloop()


#Fenetre de menu de fin de jeu
def menuFin():
    fenFin= Tk() #Création de la fenêtre
    fenFin.title("Sauvegarde de votre partie")
    fenFin.geometry('600x150')
    Label(text= "Votre score :" + str(score) + "\n" + "Sauvegarder ?").pack() #Affichage du score et demande au joueur s'il veut, ou non, sauvegarder

#Fenetre d'ajout de score
    def ajoutScore():
        fenFin.destroy() #Fermeture de la fenêtre du menu de fin de jeu
        fenSauvegarde =Tk() #Création de la fenêtre
        fenSauvegarde.title("Sauvegarde de votre partie")
        fenSauvegarde.geometry('600x150')
        Label(fenSauvegarde, text = "Votre nom ?").pack() #Demande au joueur son nom
        nomSaisi = StringVar() #Sauvegarde de son nom dans 'nomSaisi'
        nom = Entry(fenSauvegarde, textvariable = nomSaisi)
        nom.pack()
        def sauvegarde():
            ajouter(str(nomSaisi.get()),str(score)) #Execution de la fonction 'ajouter'
            fenSauvegarde.destroy()
        boutonValidation = Button(fenSauvegarde, text ="Valider", command = sauvegarde)
        boutonValidation.pack()

    def rejouer():
        fenFin.destroy()
        menu()
        
#Choix pour le joueur 
    boutonOui = Button(fenFin, text='Sauvegarder', command = ajoutScore )    
    boutonNon = Button(fenFin, text='Ne pas sauvegarder', command = fenFin.destroy )
    boutonOui.pack()
    boutonNon.pack()

#Fonction permettant d'ajouter le nom et le score du joueur à un fichier
def ajouter(nom, score):
    fichier_ecriture = open('scores.txt' , 'a')
    fichier_ecriture.write(nom + " : " + score + "\n")
    fichier_ecriture.close()

#Fonction triant un tableau de score
def tri(t):
    t.sort(key = lambda x : int(x.split(" : ")[1]), reverse = True)
    
#Fonction permettant de trier les scores enregistrés
def trier():
    t=[]
    fichier_lecture = open("scores.txt", 'r')
    for ligne in fichier_lecture :
        t.append(ligne)
    fichier_lecture.close()
    tri(t)
    print('Classement des joueurs :')
    print()
    for ligne in t :
        print(ligne, end="")
    print()
    
#Lancement du jeu
def menu():
    Jeu()
    menuFin()

def pause():
    input()

menu()

############
### TEST ###
############

# Pour consulter le classement de vos scores saisissez l'instruction : trier()
